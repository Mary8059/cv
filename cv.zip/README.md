
  # Resume Builder

  This is a code bundle for Resume Builder. The original project is available at https://www.figma.com/design/u4otHO3FIP3B0G3ycvbIcD/Resume-Builder.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  